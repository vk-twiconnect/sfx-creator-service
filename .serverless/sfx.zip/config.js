module.exports = function() {
    return {
        keys : ['f84e2396-9c14-11e8-98d0-529269fb1459', 'f84e2396-9c14-11e8-98d0-529269fb1460']
    }
}